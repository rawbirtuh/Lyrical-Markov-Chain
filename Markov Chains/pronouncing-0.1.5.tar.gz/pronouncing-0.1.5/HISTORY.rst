.. :changelog:

History
=======

0.1.5 (2017-04-13)
------------------

* Messed up the PyPI upload. Yay!

0.1.4 (2017-04-12)
------------------

* Improved performance when retrieving rhyming words. (Based on pull request
  proposed by `WillPiledriver <https://github.com/WillPiledriver>`_.)


0.1.3 (2017-01-17)
------------------

* Various tweaks and performance improvements.


0.1.2 (2015-06-23)
------------------

* Pre-compiled regex for improved performance. (Contributed by John Wiseman.)

0.1.1 (2015-06-12)
---------------------

* First release on PyPI.
