============================
Credits and Acknowledgements
============================

Lead developer: Allison Parrish <allison@decontextualize.com>.

This package was originally developed as part of my Spring 2015 research
fellowship at `ITP <http://itp.nyu.edu/itp/>`_. Thank you to the program and
its students for their interest and support!

